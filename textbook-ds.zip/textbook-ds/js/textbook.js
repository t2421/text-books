/* =============================================================
   textbook.js — インタラクション層
   
   読み込んでおくと、以下の機能が自動で有効になる:
   - 読了進捗バー (#progressFill)
   - 目次ドロワー (#tocToggle / #tocClose / #tocBackdrop / #tocDrawer)
   - フェードイン (.chapter__header / .key-concept / .summary)
   
   どの要素も「あれば動く、なくても黙る」設計。
   ============================================================= */

(function () {
  'use strict';

  // ── 読了進捗バー ──────────────────────────────
  const progressFill = document.getElementById('progressFill');
  if (progressFill) {
    let ticking = false;
    window.addEventListener('scroll', function () {
      if (!ticking) {
        window.requestAnimationFrame(function () {
          const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
          const scrolled = (window.scrollY / scrollHeight) * 100;
          progressFill.style.width = Math.min(scrolled, 100) + '%';
          ticking = false;
        });
        ticking = true;
      }
    });
  }

  // ── 目次ドロワー ──────────────────────────────
  const tocToggle = document.getElementById('tocToggle');
  const tocDrawer = document.getElementById('tocDrawer');
  const tocClose = document.getElementById('tocClose');
  const tocBackdrop = document.getElementById('tocBackdrop');

  function openToc() {
    if (tocDrawer) tocDrawer.classList.add('is-open');
    if (tocBackdrop) tocBackdrop.classList.add('is-open');
  }
  function closeToc() {
    if (tocDrawer) tocDrawer.classList.remove('is-open');
    if (tocBackdrop) tocBackdrop.classList.remove('is-open');
  }

  if (tocToggle) tocToggle.addEventListener('click', openToc);
  if (tocClose) tocClose.addEventListener('click', closeToc);
  if (tocBackdrop) tocBackdrop.addEventListener('click', closeToc);

  // 目次内リンクをクリックしたら閉じる
  if (tocDrawer) {
    tocDrawer.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', closeToc);
    });
  }

  // ESC で閉じる
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeToc();
  });

  // ── フェードイン (Intersection Observer) ──────
  if ('IntersectionObserver' in window) {
    const fadeTargets = document.querySelectorAll(
      '.chapter__header, .key-concept, .summary'
    );
    fadeTargets.forEach(function (el) { el.classList.add('fade-in'); });

    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -50px 0px'
    });

    fadeTargets.forEach(function (el) { observer.observe(el); });
  }
})();
